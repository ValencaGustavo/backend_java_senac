package controller;

import java.sql.*;

import model.MySQLConnector;

public class Logar {
    public static String logar(String email, String senha) {

    }
}
